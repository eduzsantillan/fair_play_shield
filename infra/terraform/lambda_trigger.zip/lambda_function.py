import boto3
import json
import os

def lambda_handler(event, context):
    ssm = boto3.client('ssm')
    instance_id = os.environ['EC2_INSTANCE_ID']
    
    response = ssm.send_command(
        InstanceIds=[instance_id],
        DocumentName='AWS-RunShellScript',
        Parameters={
            'commands': [
                'cd /home/ec2-user/fair_play_shield',
                'docker-compose exec -T app python main.py --step all --seasons 1',
                'echo "Pipeline completed at $(date)"'
            ]
        },
        TimeoutSeconds=3600
    )
    
    command_id = response['Command']['CommandId']
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Pipeline triggered successfully',
            'command_id': command_id,
            'instance_id': instance_id
        })
    }
